package com.example.iris_rec

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
